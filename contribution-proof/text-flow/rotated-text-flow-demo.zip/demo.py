"""Synthetic rotated-word demonstration by iAlturki. No external input files."""

import argparse
import json
from pathlib import Path


def create(output):
    from reportlab.pdfgen import canvas

    output.mkdir(parents=True, exist_ok=True)
    path = output / "rotated-words.pdf"
    pdf = canvas.Canvas(str(path), pagesize=(180, 240), invariant=True)
    pdf.setAuthor("iAlturki")
    pdf.setTitle("Synthetic rotated words")
    pdf.setSubject("pdfplumber word segmentation regression demonstration")
    pdf.translate(100, 205)
    pdf.rotate(-90)
    pdf.setFont("Courier", 20)
    pdf.drawString(0, 0, "ALPHA BETA")
    pdf.showPage()
    pdf.save()
    print("Created synthetic input:", path.name)


def capture(output, label, source):
    import pdfplumber

    kwargs = {"use_text_flow": True}
    with pdfplumber.open(output / "rotated-words.pdf") as pdf:
        page = pdf.pages[0]
        words = page.extract_words(**kwargs)
        texts = [word["text"] for word in words]
        expected = list("ALPHABETA") if label == "original" else ["ALPHA", "BETA"]
        assert texts == expected, (label, texts)
        assert all(word["direction"] == "ttb" for word in words)
        color = (193, 42, 57) if label == "original" else (4, 128, 91)
        image = page.to_image(resolution=144, antialias=True)
        image.draw_rects(words, fill=None, stroke=color, stroke_width=2)
        image.annotated.save(output / (label + ".png"), optimize=True)
        keys = ("text", "x0", "top", "x1", "bottom", "direction")
        result = {
            "label": label,
            "source_commit": source,
            "pdfplumber_version": pdfplumber.__version__,
            "arguments": kwargs,
            "words": [{key: word[key] for key in keys} for word in words],
        }
        (output / (label + ".json")).write_text(
            json.dumps(result, indent=2) + "\n", encoding="utf-8"
        )
        print(label + ":", texts)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=["create", "capture"])
    parser.add_argument("--output", type=Path, default=Path("output/pdf"))
    parser.add_argument("--label", choices=["original", "fixed"])
    parser.add_argument("--source", default="working-tree")
    args = parser.parse_args()
    if args.operation == "create":
        create(args.output)
    else:
        if not args.label:
            parser.error("capture requires --label")
        capture(args.output, args.label, args.source)
